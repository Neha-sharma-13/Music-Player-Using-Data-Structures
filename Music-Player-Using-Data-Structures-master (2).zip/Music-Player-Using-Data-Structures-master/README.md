# Music-Player-Using-Data-Structures
This is the project made for Data Structures and Algorithm Course. Here we implement a C++ based Basic Music Player using the knowledge of various Data structures learnt as part of course CSE2003. Data structures used include a doubly linked list, stacks and queues. File handling to read and write songs has also been used.
